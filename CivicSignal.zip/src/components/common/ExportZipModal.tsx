import React, { useState } from 'react';
import { Download, FolderArchive, CheckCircle2, Loader2, X } from 'lucide-react';

interface ExportZipModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportZipModal: React.FC<ExportZipModalProps> = ({ isOpen, onClose }) => {
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownload = async () => {
    try {
      setDownloading(true);
      const res = await fetch('/api/export-project');
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'CivicSignal-Platform-Source.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      setDownloadSuccess(true);
    } catch (err) {
      console.error('Error downloading zip:', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <FolderArchive className="w-5 h-5 text-blue-600" />
            <h3 className="font-semibold text-slate-800">Download Complete Project ZIP</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-sm text-slate-600">
          <p>
            You can export the entire <strong>CivicSignal</strong> project directory as a clean, self-contained <code>.zip</code> package containing all frontend, backend, server routing, and database modules.
          </p>

          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs space-y-1">
            <div className="font-semibold text-slate-700">Package Includes:</div>
            <div>• Full Express full-stack server & Vite integration (<code>server.ts</code>)</div>
            <div>• Database persistence engine & demo seed scripts</div>
            <div>• Duplicate detection & Gemini AI analysis modules</div>
            <div>• Priority scoring, SLA deadline tracking, & analytics</div>
            <div>• Complete responsive React & Tailwind components</div>
          </div>

          {downloadSuccess ? (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 flex items-center gap-2 text-xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Project archive downloaded successfully! (CivicSignal-Platform-Source.zip)</span>
            </div>
          ) : null}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-md transition-colors"
            >
              Close
            </button>
            <button
              onClick={handleDownload}
              disabled={downloading}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs rounded-md shadow-xs transition-colors disabled:opacity-50"
            >
              {downloading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Packaging ZIP...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" /> Download Project (.zip)
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
